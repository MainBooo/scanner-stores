import "dotenv/config"
import { createQueue, createRedis } from "./queue/queue"
import { runDomainScanWorker } from "./workers/domain-scan.worker"
import { runPageCheckWorker } from "./workers/page-check.worker"
import { runDiffDetectWorker } from "./workers/diff-detect.worker"

async function main() {
  const redis = createRedis()
  await redis.ping()

  createQueue("domain_scan")
  createQueue("page_check")
  createQueue("diff_detect")

  runDomainScanWorker()
  runPageCheckWorker()
  runDiffDetectWorker()

  // eslint-disable-next-line no-console
  console.log("Workers started: domain_scan, page_check, diff_detect")
}

main().catch((e) => {
  // eslint-disable-next-line no-console
  console.error(e)
  process.exit(1)
})
