import { createWorker } from "../queue/queue"
import { PrismaClient } from "@prisma/client"
import { chromium } from "playwright"
import { classifyPath } from "./classify"

function normalizeDomain(domain: string) {
  return domain.replace(/^https?:\/\//, "").replace(/\/$/, "")
}

export function runDomainScanWorker() {
  const prisma = new PrismaClient()

  return createWorker("domain_scan", async (job) => {
    const { competitorId } = job.data as { competitorId: string }
    const competitor = await prisma.competitor.findUnique({ where: { id: competitorId } })
    if (!competitor) return { ok: false, reason: "competitor not found" }

    const domain = normalizeDomain(competitor.domain)
    const baseUrl = `https://${domain}`

    const maxPages = Number(process.env.SCAN_MAX_PAGES ?? 80)
    const timeoutMs = Number(process.env.SCAN_TIMEOUT_MS ?? 20000)

    const browser = await chromium.launch({ headless: true })
    const page = await browser.newPage()
    page.setDefaultTimeout(timeoutMs)

    const discovered = new Set<string>()
    const q: string[] = [baseUrl]

    async function push(u: string) {
      try {
        const url = new URL(u)
        if (url.hostname !== new URL(baseUrl).hostname) return
        const normalized = url.origin + url.pathname
        if (discovered.has(normalized)) return
        discovered.add(normalized)
        q.push(normalized)
      } catch {}
    }

    try {
      while (q.length && discovered.size < maxPages) {
        const current = q.shift()!
        try {
          await page.goto(current, { waitUntil: "domcontentloaded" })
        } catch {
          continue
        }
        const links: string[] = await page.$$eval("a[href]", (as) =>
          as.map((a) => (a as HTMLAnchorElement).href).slice(0, 300),
        )
        for (const l of links) await push(l)
      }
    } finally {
      await browser.close()
    }

    const urls = Array.from(discovered).slice(0, maxPages)

    for (const u of urls) {
      const url = new URL(u)
      const path = url.pathname || "/"
      const pageType = classifyPath(path)
      await prisma.page.upsert({
        where: { competitorId_url: { competitorId, url: u } },
        update: { pageType },
        create: { competitorId, url: u, path, pageType },
      })
    }

    await prisma.competitor.update({
      where: { id: competitorId },
      data: { lastScanAt: new Date(), status: "active" },
    })

    return { ok: true, discovered: urls.length }
  })
}
