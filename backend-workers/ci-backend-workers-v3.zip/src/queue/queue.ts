import Redis from "ioredis"
import { Queue, Worker } from "bullmq"

export function redisUrl() {
  return process.env.REDIS_URL ?? "redis://localhost:6379"
}
export function createRedis() {
  return new Redis(redisUrl(), { maxRetriesPerRequest: null })
}
export function createQueue(name: string) {
  const connection = createRedis()
  return new Queue(name, { connection })
}
export function createWorker<T>(name: string, processor: (job: any) => Promise<T>) {
  const connection = createRedis()
  return new Worker(name, processor, { connection, concurrency: 2 })
}
