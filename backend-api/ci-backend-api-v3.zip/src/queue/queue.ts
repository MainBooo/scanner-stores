import Redis from "ioredis"
import { Queue } from "bullmq"

export function redisUrl() {
  return process.env.REDIS_URL ?? "redis://localhost:6379"
}
export function createRedis() {
  return new Redis(redisUrl(), { maxRetriesPerRequest: null })
}
export function createQueue(name: string) {
  const connection = createRedis()
  return new Queue(name, { connection })
}
