import { Injectable } from "@nestjs/common"
import { PrismaService } from "../prisma/prisma.service"
import { createQueue } from "../queue/queue"

@Injectable()
export class JobsService {
  constructor(private prisma: PrismaService) {}

  async tick() {
    const now = new Date()
    const pages = await this.prisma.page.findMany({
      where: { monitoringEnabled: true },
      take: 300,
      orderBy: { lastCheckedAt: "asc" },
    })

    const due = pages.filter((p) => {
      if (!p.lastCheckedAt) return true
      const intervalMs = p.checkIntervalMin * 60_000
      return now.getTime() - p.lastCheckedAt.getTime() >= intervalMs
    })

    const q = createQueue("page_check")
    for (const p of due) {
      await q.add("page_check", { pageId: p.id }, { removeOnComplete: 500, removeOnFail: 500 })
    }
    return { enqueued: due.length }
  }
}
