import "dotenv/config"
import { NestFactory } from "@nestjs/core"
import { AppModule } from "./app.module"
import { ConfigService } from "@nestjs/config"

async function bootstrap() {
  const app = await NestFactory.create(AppModule)
  const cfg = app.get(ConfigService)
  const port = Number(cfg.get("PORT") ?? 4000)
  const origin = cfg.get("CORS_ORIGIN") ?? "http://localhost:3000"
  app.enableCors({ origin, credentials: true })
  await app.listen(port)
  // eslint-disable-next-line no-console
  console.log(`API listening on http://localhost:${port}`)
}
bootstrap()
