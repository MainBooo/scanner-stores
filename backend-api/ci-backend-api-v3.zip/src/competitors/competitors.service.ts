import { Injectable } from "@nestjs/common"
import { PrismaService } from "../prisma/prisma.service"
import { createQueue } from "../queue/queue"

@Injectable()
export class CompetitorsService {
  constructor(private prisma: PrismaService) {}

  list() {
    return this.prisma.competitor.findMany({ orderBy: { createdAt: "desc" } })
  }

  async create(domain: string, displayName?: string) {
    const normalized = domain.toLowerCase().trim().replace(/^https?:\/\//, "").replace(/\/$/, "")
    const competitor = await this.prisma.competitor.create({
      data: { domain: normalized, displayName: displayName || null },
    })
    const q = createQueue("domain_scan")
    await q.add("domain_scan", { competitorId: competitor.id }, { removeOnComplete: 200, removeOnFail: 200 })
    return competitor
  }

  async suggestions(competitorId: string) {
    const pages = await this.prisma.page.findMany({
      where: { competitorId },
      orderBy: [{ pageType: "asc" }, { createdAt: "asc" }],
      take: 80,
    })
    const reason = (t: string) => {
      const m: Record<string, string> = {
        home: "Homepage",
        pricing: "Detected by URL pattern",
        product: "Detected by URL pattern",
        category: "Detected by URL pattern",
        blog: "Detected by URL pattern",
        docs: "Detected by URL pattern",
        other: "Discovered during scan",
      }
      return m[t] ?? "Discovered"
    }
    return pages.map((p) => ({ url: p.url, pageType: p.pageType, reason: reason(p.pageType) }))
  }
}
